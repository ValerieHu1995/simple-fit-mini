<template>
  <div class="hello">
    <router-link to="/login">这里是欢迎海报还没设计</router-link>
  </div>
</template>

<script>
export default {
  name: "PageUserWelcome"
};
</script>

<style scoped>

</style>
