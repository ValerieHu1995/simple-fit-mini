<template>
    <div class="LayerBottom" id="PageUserLogin">
        <div class="md-field">
            <md-field>
                <label>用户名</label>
                <md-textarea md-autogrow></md-textarea>
            </md-field>
            <md-field>
                <label>密码</label>
                <md-textarea md-autogrow></md-textarea>
            </md-field>
        </div>
        <md-button><router-link to="/index">登陆</router-link></md-button>
    </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";

Vue.use(VueMaterial);

export default {};
</script>

<style scoped>
.md-field {
  margin-top: 0px;
}
</style>
