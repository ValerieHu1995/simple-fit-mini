<template>
  <div class="LayerMiddle" id="PartStatistics">
    <swiper>
        <swiper-slide>
          <div class="md-layout">
            <div class="md-layout-item">
              <div>新增买卡</div>
              <div>{{DataNewCard}}</div>
            </div>
            <div class="md-layout-item">
              <div>新增买课</div>
              <div>{{DataNewClass}}</div>
            </div>
            <div class="md-layout-item">
              <div>新增注册</div>
              <div>{{DataNewMember}}</div>
            </div>
          </div>
        </swiper-slide>
        <swiper-slide>
          <div class="md-layout">
            <div class="md-layout-item">
              <div>全部买卡</div>
              <div>{{DataAllCard}}</div>
            </div>
            <div class="md-layout-item">
              <div>全部买课</div>
              <div>{{DataAllClass}}</div>
            </div>
            <div class="md-layout-item">
              <div>全部注册</div>
              <div>{{DataAllMember}}</div>
            </div>
          </div>
        </swiper-slide>
      </swiper>
  </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";

Vue.use(VueMaterial);

export default {
  name: "PartStatistics",
  components: {
    swiper,
    swiperSlide
  },
  data: () => ({
    DataNewCard: 100,
    DataNewClass: 100,
    DataNewMember: 100,
    DataAllCard: 1000,
    DataAllClass: 1000,
    DataAllMember: 1000
  })
};
</script>

<style scoped>
.md-layout {
  padding-top: 10px;
  padding-bottom: 10px;
}
.md-layout-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>