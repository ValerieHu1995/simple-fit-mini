<template>
    <div class="LayerBottom" id="PageUserIndex">
        <PartNavigationBar/>
        <PartStatistics/>
        <br>
        <PartCharts/>
        <br>
        <PartTools/>
        <br>
        <br>
        <br>
        <br>
        <br>
    </div>
</template>

<script>
import Vue from "vue";
import PartNavigationBar from "../PartNavigationBar/PartNavigationBar.vue";
import PartStatistics from "./PartStatistics.vue";
import PartCharts from "./PartCharts.vue";
import PartTools from "./PartTools.vue";

export default {
  name: "PageUserIndex",
  components: {
      PartNavigationBar,
      PartStatistics,
      PartCharts,
      PartTools
  }
};
</script>

<style scoped>

</style>
