import PageUserWelcome from '@/components/PageUserWelcome'
import PageUserLogin from '@/components/PageUserLogin'

import PageUserAccount from '@/components/PartNavigationBar/PageUserAccount'

import PageUserIndex from '@/components/PageUserIndex/PageUserIndex'
import PageUserOpenDoor from '@/components/PageUserIndex/PageUserOpenDoor'
import PageRecordOpen from '@/components/PageUserIndex/PageRecordOpen'
import PageRecordBuy from '@/components/PageUserIndex/PageRecordBuy'
import PageRecordBook from '@/components/PageUserIndex/PageRecordBook'

const routers = [{
  path: '/',
  component: PageUserWelcome
}, {
  path: '/welcome',
  component: PageUserWelcome
}, {
  path: '/login',
  component: PageUserLogin
}, {
  path: '/nav/account',
  component: PageUserAccount
},{
  path: '/index',
  component: PageUserIndex
},{
  path: '/index/open-door',
  component: PageUserOpenDoor
},{
  path: '/index/record-open',
  component: PageRecordOpen
},{
  path: '/index/record-buy',
  component: PageRecordBuy
},{
  path: '/index/record-book',
  component: PageRecordBook
}]
export default routers
