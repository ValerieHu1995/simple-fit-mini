<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import PageUserWelcome from "./components/PageUserWelcome";

export default {
  name: "App",
  components: {
    PageUserWelcome
  },
  data: () => ({})
};
</script>


<style>
@import "./assets/css/theme.css";

</style>
