import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: []
})

import PartNavigationBar from '../PartNavigationBar.vue'

const PartNavigationBar = {
  install: function (Vue) {
    Vue.component('PartNavigationBar', PartNavigationBar)
  }
};
