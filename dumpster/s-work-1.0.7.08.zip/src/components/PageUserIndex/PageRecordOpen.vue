<template>
    <div class="LayerBottom" id="PageRecordOpen">
        <PartNavigationBar/>
        <md-list class="LayerBetween">
            <md-list-item @click="NavToPageUserIndex">
                <span class="md-list-item-text">前一天</span>
                <span class="md-list-item-text">{{ChoseDate}}</span>
                <span class="md-list-item-text">后一天</span>
            </md-list-item>
            <md-divider class="Divider"/>
            <md-content class="md-scrollbar">
                <div  v-for="item in arr" :key="item">
                    <md-list-item>
                        <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
                        <span class="md-list-item-text">开门记录</span>
                    </md-list-item>
                    <md-divider class="Divider"/>
                </div>
            </md-content>
        <md-list-item>
          <span class="md-list-item-text">今日客流</span>
          <span class="md-list-item-text">10</span>
        </md-list-item>
      </md-list>
      <br>
    </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
import PartNavigationBar from "../PartNavigationBar/PartNavigationBar.vue";

Vue.use(VueMaterial);

export default {
  name: "PageRecordOpen",
  components: {
    PartNavigationBar
  },
  data: () => ({
    ChoseDate: "06-10",
    arr: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  })
};
</script>

<style scoped>
.md-content {
  max-width: 400px;
  max-height: 490px;
  overflow: auto;
}
</style>


