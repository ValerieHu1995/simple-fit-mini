<template>
    <div class="LayerMiddle" id="PartTools">
        <div class="md-layout">
            <router-link to="/index/open-door" class="md-layout-item">
                <div>图标</div>
                <div>扫码开门</div>
            </router-link>
            <router-link to="/index/record-open" class="md-layout-item">
                <div>图标</div>
                <div>开门记录</div>
            </router-link>
            <router-link to="/index/record-buy" class="md-layout-item">
                <div>图标</div>
                <div>购买记录</div>
            </router-link>
            <router-link to="/index/record-book" class="md-layout-item">
                <div>图标</div>
                <div>预约记录</div>
            </router-link>
        </div>
        <div class="md-layout">
            <div class="md-layout-item">
                <div>图标</div>
                <div>通知发送</div>
            </div>
            <div class="md-layout-item">
                <div>图标</div>
                <div>描述2</div>
            </div>
            <div class="md-layout-item">
                <div>图标</div>
                <div>描述3</div>
            </div>
            <div class="md-layout-item">
                <div>图标</div>
                <div>描述4</div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  name: "PartTools"
};
</script>

<style scoped>
.md-title {
  padding-top: 10px;
  margin-left: 10px;
  margin-bottom: 10px;
}
.md-layout-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 10px;
  padding-bottom: 10px;
}
</style>
