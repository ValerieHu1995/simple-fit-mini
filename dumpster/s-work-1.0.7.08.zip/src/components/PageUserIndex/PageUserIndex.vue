<template>
    <div class="LayerBottom" id="PageUserIndex">
        <PartNavigationBar/>
        <div class="LayerBetween">
            <PartStatistics/>
            <PartCharts style="margin-top:14px;"/>
            <PartTools style="margin-top:14px;"/>
        </div>
        <br>
        <br>
        <br>
        <br>
    </div>
</template>

<script>
import Vue from "vue";
import PartNavigationBar from "../PartNavigationBar/PartNavigationBar.vue";
import PartStatistics from "./PartStatistics.vue";
import PartCharts from "./PartTimetable.vue";
import PartTools from "./PartTools.vue";

export default {
  name: "PageUserIndex",
  components: {
    PartNavigationBar,
    PartStatistics,
    PartCharts,
    PartTools
  }
};
</script>

<style scoped>
</style>
