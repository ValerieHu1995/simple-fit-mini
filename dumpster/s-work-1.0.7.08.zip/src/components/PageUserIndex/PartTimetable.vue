<template>
  <div class="LayerMiddle" id="PartTimetable">
    <md-list>
      <md-tabs class="md-primary" md-alignment="centered">
        <md-tab md-label="7.08">
          <md-content class="md-scrollbar">
            <div  v-for="item in arr" :key="item">
              <md-list-item>
                <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
                <span class="md-list-item-text">预约信息</span>
              </md-list-item>
              <md-divider class="Divider"/>
            </div>
          </md-content>
          <md-list-item>
            <span class="md-list-item-text">今日上课</span>
            <span class="md-list-item-text">10</span>
          </md-list-item>
        </md-tab>
        <md-tab md-label="7.09">
          <md-content class="md-scrollbar">
            <div  v-for="item in arr" :key="item">
              <md-list-item>
                <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
                <span class="md-list-item-text">预约信息</span>
              </md-list-item>
              <md-divider class="Divider"/>
            </div>
          </md-content>
          <md-list-item>
            <span class="md-list-item-text">上课预约</span>
            <span class="md-list-item-text">10</span>
          </md-list-item>
        </md-tab>
        <md-tab md-label="7.10">
          <md-content class="md-scrollbar">
            <div  v-for="item in arr" :key="item">
              <md-list-item>
                <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
                <span class="md-list-item-text">预约信息</span>
              </md-list-item>
              <md-divider class="Divider"/>
            </div>
          </md-content>
          <md-list-item>
            <span class="md-list-item-text">上课预约</span>
            <span class="md-list-item-text">10</span>
          </md-list-item>
        </md-tab>
        <md-tab md-label="7.11">
          <md-content class="md-scrollbar">
            <div  v-for="item in arr" :key="item">
              <md-list-item>
                <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
                <span class="md-list-item-text">预约信息</span>
              </md-list-item>
              <md-divider class="Divider"/>
            </div>
          </md-content>
          <md-list-item>
            <span class="md-list-item-text">上课预约</span>
            <span class="md-list-item-text">10</span>
          </md-list-item>
        </md-tab>
        <md-tab md-label="7.12">
          <md-content class="md-scrollbar">
            <div  v-for="item in arr" :key="item">
              <md-list-item>
                <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
                <span class="md-list-item-text">预约信息</span>
              </md-list-item>
              <md-divider class="Divider"/>
            </div>
          </md-content>
          <md-list-item>
            <span class="md-list-item-text">上课预约</span>
            <span class="md-list-item-text">10</span>
          </md-list-item>
        </md-tab>
      </md-tabs>
    </md-list>
  </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";

export default {
  name: "PartTimetable",
  data: () => ({
    arr: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  }),
  components: {},
  computed: {},
  methods: {},
  mounted() {}
};
</script>

<style scoped>
.md-content {
  max-width: 400px;
  max-height: 200px;
  overflow: auto;
}
</style>
