<template>
  <div class="LayerMiddle" id="PartStatistics">
    <swiper>
        <swiper-slide>
          <div class="md-layout">
            <div class="md-layout-item">
              <div>{{DataNewClass}}</div>
              <div>有课会员</div>
            </div>
            <div class="md-layout-item">
              <div>{{DataNewMember}}</div>
              <div>我的会员</div>
            </div>
          </div>
        </swiper-slide>
        <swiper-slide>
          <div class="md-layout">
            <div class="md-layout-item">
              <div>{{DataAllClass}}</div>
              <div>全部买课</div>
            </div>
            <div class="md-layout-item">
              <div>{{DataAllMember}}</div>
              <div>全部注册</div>
            </div>
          </div>
        </swiper-slide>
      </swiper>
  </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";

Vue.use(VueMaterial);

export default {
  name: "PartStatistics",
  components: {
    swiper,
    swiperSlide
  },
  data: () => ({
    DataNewClass: 17,
    DataNewMember: 66,
    DataAllClass: 1000,
    DataAllMember: 1000
  })
};
</script>

<style scoped>
.md-layout {
  padding-top: 10px;
  padding-bottom: 10px;
}
.md-layout-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>