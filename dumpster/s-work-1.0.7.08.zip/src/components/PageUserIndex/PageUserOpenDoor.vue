<template>
    <div class="LayerBottom" id="PageUserIndex">
        <PartNavigationBar/>
        <div>扫码开门</div>
    </div>
</template>

<script>
import Vue from "vue";
import PartNavigationBar from "../PartNavigationBar/PartNavigationBar.vue";

export default {
  name: "PageUserIndex",
  components: {
    PartNavigationBar
  }
};
</script>

<style scoped>

</style>
