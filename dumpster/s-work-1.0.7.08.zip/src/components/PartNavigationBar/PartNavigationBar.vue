<template>
  <div id="PartNavigationBar">
    <md-toolbar md-elevation="0"> 
      <md-menu md-direction="bottom-end">
        <md-button class="md-button" md-menu-trigger>{{ShopAll[0].name}}</md-button>
        <md-menu-content class="ActionBackground">
          <md-menu-item v-for="shops in ShopAll" :key="shops.key" >{{shops.name}}</md-menu-item>
        </md-menu-content>
      </md-menu>
      <div class="md-toolbar-section-end">
        <md-button class="md-icon-button" @click="showNavigation = true">
          <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
        </md-button>
      </div>
    </md-toolbar>
    <md-drawer class="LayerBottom" :md-active.sync="showNavigation" md-fixed="true" md-right="true" md-permanent="full">
      <md-toolbar md-elevation="0">
        <md-button class="md-icon-button">
          <md-avatar><img src="../../assets/avatar.jpg" alt="Avatar"></md-avatar>
        </md-button>
        <md-button class="md-button">账户信息</md-button>
      </md-toolbar>
      <md-list class="LayerBetween">
        <md-list-item @click="NavToPageUserIndex">
          <span class="md-list-item-text">我的主页</span>
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item @click="NavToPageUserAccount">
          <span class="md-list-item-text">我的钱包</span>
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item>
          <span class="md-list-item-text">通用设置</span>
          <md-badge class="md-square" md-content="new" />
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item>
          <span class="md-list-item-text">系统通知</span>
          <md-badge class="md-square" md-content="6" />
        </md-list-item>
      </md-list>
    </md-drawer>
    </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";

Vue.use(VueMaterial);

export default {
  name: "PartNavigationBar",
  data: () => ({
    ShopAll: [
      {
        key: 0,
        name: "Simple-Fit 文津路店"
      },
      {
        key: 1,
        name: "Simple-Fit 文泽路店"
      },
      {
        key: 2,
        name: "Simple-Fit 文汇路店"
      }
    ],
    showNavigation: false,
    showSidepanel: false
  }),
  methods: {
    NavToPageUserIndex: function() {
      this.$router.push({ path: "/index" });
    },
    NavToPageUserAccount: function() {
      this.$router.push({ path: "/nav/account" });
    }
  }
};
</script>

<style scoped>
.md-square {
  background-color: #0484d3;
}
</style>
