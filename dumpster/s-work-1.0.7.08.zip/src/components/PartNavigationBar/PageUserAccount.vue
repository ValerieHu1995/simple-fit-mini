<template>
    <div class="LayerBottom" id="PageUserAccount">
    <PartNavigationBar/>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <md-list class="LayerMiddle">
        <md-list-item>
            <span class="md-list-item-text">S-fit账号</span>
            <span class="md-list-item-text">1234567890</span>
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item>
            <span class="md-list-item-text">手机号</span>
            <span class="md-list-item-text">1234567890</span>
        </md-list-item>
    </md-list>
    <br>
    <md-list class="LayerMiddle">
        <md-list-item>
            <span class="md-list-item-text">微信</span>
            <span class="md-list-item-text">未绑定</span>
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item>
            <span class="md-list-item-text">QQ</span>
            <span class="md-list-item-text">已绑定</span>
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item>
            <span class="md-list-item-text">微博</span>
            <span class="md-list-item-text">已绑定</span>
        </md-list-item>
        <md-divider class="Divider"/>
        <md-list-item>
            <span class="md-list-item-text">支付宝</span>
            <span class="md-list-item-text">已绑定</span>
        </md-list-item>
    </md-list>
    <br>
    <md-list class="LayerMiddle">
        <md-list-item>
            <span class="md-list-item-text">修改密码</span>
        </md-list-item>
    </md-list>
    <br>
    </div>
</template>

<script>
import Vue from "vue";
import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
import PartNavigationBar from "./PartNavigationBar.vue";

Vue.use(VueMaterial);

export default {
  name: "PageUserAccount",
  components: {
    PartNavigationBar
  }
};
</script>

<style scoped>
</style>
